export enum ConnectionQuality {
  UNKNOWN = "UNKNOWN",
  GOOD = "GOOD",
  BAD = "BAD",
}
