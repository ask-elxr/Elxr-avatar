export const LIVEKIT_COMMAND_CHANNEL_TOPIC = "agent-control";
export const LIVEKIT_SERVER_RESPONSE_CHANNEL_TOPIC = "agent-response";
