export const API_URL = "https://api.liveavatar.com";
