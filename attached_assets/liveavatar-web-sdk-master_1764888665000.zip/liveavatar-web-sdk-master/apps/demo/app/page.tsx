import { LiveAvatarDemo } from "../src/components/LiveAvatarDemo";

export default function Home() {
  return <LiveAvatarDemo />;
}
